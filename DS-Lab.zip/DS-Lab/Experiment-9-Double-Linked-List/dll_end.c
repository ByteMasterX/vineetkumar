#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *prev;
    struct node *next;
};

struct node *head = NULL;

void insert_end() {
    struct node *temp, *ptr;
    int x;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter value: ");
    scanf("%d", &x);
    temp->data = x;
    temp->next = NULL;
    if (head == NULL) {
        temp->prev = NULL;
        head = temp;
        return;
    }
    ptr = head;
    while (ptr->next != NULL)
        ptr = ptr->next;
    ptr->next = temp;
    temp->prev = ptr;
    printf("Inserted at end: %d
", x);
}

void delete_last() {
    struct node *temp = head;
    if (head == NULL) {
        printf("List empty
");
        return;
    }
    if (head->next == NULL) {
        free(head);
        head = NULL;
        return;
    }
    while (temp->next != NULL)
        temp = temp->next;
    temp->prev->next = NULL;
    free(temp);
    printf("Last node deleted
");
}

void display() {
    struct node *temp = head;
    if (head == NULL) {
        printf("List empty
");
        return;
    }
    printf("List elements: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("
");
}

int main() {
    int ch;
    printf("1.Insert End
2.Delete Last
3.Display
4.Exit
");
    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);
        switch (ch) {
            case 1: insert_end(); break;
            case 2: delete_last(); break;
            case 3: display(); break;
            case 4: exit(0);
        }
    }
    return 0;
}