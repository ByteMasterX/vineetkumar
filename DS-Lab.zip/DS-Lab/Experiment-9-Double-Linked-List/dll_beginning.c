#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *prev;
    struct node *next;
};

struct node *head = NULL;

void insert_begin() {
    struct node *temp;
    int x;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter value: ");
    scanf("%d", &x);
    temp->data = x;
    temp->prev = NULL;
    temp->next = head;
    if (head != NULL)
        head->prev = temp;
    head = temp;
    printf("Inserted at beginning: %d
", x);
}

void delete_first() {
    struct node *temp;
    if (head == NULL) {
        printf("List empty
");
        return;
    }
    temp = head;
    head = head->next;
    if (head != NULL)
        head->prev = NULL;
    free(temp);
    printf("First node deleted
");
}

void display() {
    struct node *temp = head;
    if (head == NULL) {
        printf("List empty
");
        return;
    }
    printf("List elements: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("
");
}

int main() {
    int ch;
    printf("1.Insert Beginning
2.Delete First
3.Display
4.Exit
");
    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);
        switch (ch) {
            case 1: insert_begin(); break;
            case 2: delete_first(); break;
            case 3: display(); break;
            case 4: exit(0);
        }
    }
    return 0;
}