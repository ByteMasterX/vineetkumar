#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *top = NULL;

void push() {
    struct node *temp;
    int x;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter value: ");
    scanf("%d", &x);
    temp->data = x;
    temp->next = top;
    top = temp;
    printf("Pushed: %d
", x);
}

void pop() {
    struct node *temp;
    if (top == NULL) {
        printf("Stack Underflow
");
        return;
    }
    temp = top;
    top = top->next;
    printf("Popped: %d
", temp->data);
    free(temp);
}

void display() {
    struct node *temp = top;
    if (top == NULL) {
        printf("Stack is empty
");
        return;
    }
    printf("Stack elements: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("
");
}

int main() {
    int ch;
    printf("1.Push 2.Pop 3.Display 4.Exit
");
    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);
        switch (ch) {
            case 1: push(); break;
            case 2: pop(); break;
            case 3: display(); break;
            case 4: exit(0);
        }
    }
    return 0;
}