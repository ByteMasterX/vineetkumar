#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *front = NULL, *rear = NULL;

void enqueue() {
    struct node *temp;
    int x;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter value: ");
    scanf("%d", &x);
    temp->data = x;
    temp->next = NULL;
    if (rear == NULL) {
        front = rear = temp;
        printf("Enqueued: %d
", x);
        return;
    }
    rear->next = temp;
    rear = temp;
    printf("Enqueued: %d
", x);
}

void dequeue() {
    struct node *temp;
    if (front == NULL) {
        printf("Queue Underflow
");
        return;
    }
    temp = front;
    front = front->next;
    if (front == NULL)
        rear = NULL;
    printf("Dequeued: %d
", temp->data);
    free(temp);
}

void display() {
    struct node *temp = front;
    if (front == NULL) {
        printf("Queue is empty
");
        return;
    }
    printf("Queue elements: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("
");
}

int main() {
    int ch;
    printf("1.Enqueue 2.Dequeue 3.Display 4.Exit
");
    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);
        switch (ch) {
            case 1: enqueue(); break;
            case 2: dequeue(); break;
            case 3: display(); break;
            case 4: exit(0);
        }
    }
    return 0;
}