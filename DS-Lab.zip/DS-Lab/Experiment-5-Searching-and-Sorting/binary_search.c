#include <stdio.h>

int binary(int a[], int n, int key) {
    int l = 0, r = n - 1, mid;
    while (l <= r) {
        mid = (l + r) / 2;
        if (a[mid] == key)
            return mid;
        else if (a[mid] < key)
            l = mid + 1;
        else
            r = mid - 1;
    }
    return -1;
}

int main() {
    int n, a[100], key, result;
    printf("Enter size of array: ");
    scanf("%d", &n);
    printf("Enter sorted array elements: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter key to search: ");
    scanf("%d", &key);
    result = binary(a, n, key);
    if (result != -1)
        printf("Element found at index: %d
", result);
    else
        printf("Element not found
");
    return 0;
}