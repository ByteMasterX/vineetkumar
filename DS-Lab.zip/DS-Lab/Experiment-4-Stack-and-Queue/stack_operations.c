#include <stdio.h>
#define MAX 100

int stack[MAX], top = -1;

void push(int x) {
    if (top == MAX - 1) {
        printf("Stack Overflow
");
        return;
    }
    stack[++top] = x;
    printf("Pushed: %d
", x);
}

int pop() {
    if (top == -1) {
        printf("Stack Underflow
");
        return -1;
    }
    return stack[top--];
}

void display() {
    if (top == -1) {
        printf("Stack is empty
");
        return;
    }
    printf("Stack elements: ");
    for (int i = top; i >= 0; i--)
        printf("%d ", stack[i]);
    printf("
");
}

int main() {
    int ch, x;
    printf("1.Push 2.Pop 3.Display 4.Exit
");
    do {
        printf("Enter choice: ");
        scanf("%d", &ch);
        if (ch == 1) {
            printf("Enter value: ");
            scanf("%d", &x);
            push(x);
        } else if (ch == 2) {
            x = pop();
            if (x != -1)
                printf("Popped: %d
", x);
        } else if (ch == 3) {
            display();
        }
    } while (ch != 4);
    return 0;
}