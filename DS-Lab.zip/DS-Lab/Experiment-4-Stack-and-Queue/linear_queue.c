#include <stdio.h>
#define MAX 100

int queue[MAX], front = 0, rear = 0;

void insert(int x) {
    if (rear == MAX) {
        printf("Queue Overflow
");
        return;
    }
    queue[rear++] = x;
    printf("Inserted: %d
", x);
}

int delete() {
    if (front == rear) {
        printf("Queue Underflow
");
        return -1;
    }
    return queue[front++];
}

void traverse() {
    if (front == rear) {
        printf("Queue is empty
");
        return;
    }
    printf("Queue elements: ");
    for (int i = front; i < rear; i++)
        printf("%d ", queue[i]);
    printf("
");
}

int main() {
    int ch, x;
    printf("1.Insert 2.Delete 3.Traverse 4.Exit
");
    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);
        if (ch == 1) {
            printf("Enter value: ");
            scanf("%d", &x);
            insert(x);
        } else if (ch == 2) {
            x = delete();
            if (x != -1)
                printf("Deleted: %d
", x);
        } else if (ch == 3) {
            traverse();
        } else {
            break;
        }
    }
    return 0;
}