#include <stdio.h>
#define MAX 5

int cq[MAX], front = -1, rear = -1;

void insert(int x) {
    if ((rear + 1) % MAX == front) {
        printf("Queue Overflow
");
        return;
    }
    if (front == -1)
        front = rear = 0;
    else
        rear = (rear + 1) % MAX;
    cq[rear] = x;
    printf("Inserted: %d
", x);
}

int delete() {
    if (front == -1) {
        printf("Queue Underflow
");
        return -1;
    }
    int val = cq[front];
    if (front == rear)
        front = rear = -1;
    else
        front = (front + 1) % MAX;
    return val;
}

void traverse() {
    if (front == -1) {
        printf("Queue is empty
");
        return;
    }
    printf("Queue elements: ");
    int i = front;
    while (1) {
        printf("%d ", cq[i]);
        if (i == rear)
            break;
        i = (i + 1) % MAX;
    }
    printf("
");
}

int main() {
    int ch, x;
    printf("1.Insert 2.Delete 3.Traverse 4.Exit
");
    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);
        if (ch == 1) {
            printf("Enter value: ");
            scanf("%d", &x);
            insert(x);
        } else if (ch == 2) {
            x = delete();
            if (x != -1)
                printf("Deleted: %d
", x);
        } else if (ch == 3) {
            traverse();
        } else {
            break;
        }
    }
    return 0;
}