#include <stdio.h>
#include <string.h>

struct Student {
    int roll;
    char name[50];
    int age;
};

void display(struct Student s[], int n) {
    printf("
Students with age >= 20:
");
    printf("Roll	Name		Age
");
    for (int i = 0; i < n; i++)
        if (s[i].age >= 20)
            printf("%d	%s	%d
", s[i].roll, s[i].name, s[i].age);
}

int main() {
    struct Student s[5];
    printf("Enter details for 5 students (roll name age):
");
    for (int i = 0; i < 5; i++) {
        scanf("%d", &s[i].roll);
        getchar();
        fgets(s[i].name, 50, stdin);
        s[i].name[strcspn(s[i].name, "
")] = 0;
        scanf("%d", &s[i].age);
    }
    display(s, 5);
    return 0;
}