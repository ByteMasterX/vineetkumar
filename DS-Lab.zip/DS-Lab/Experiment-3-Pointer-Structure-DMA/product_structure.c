#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Product {
    int pno;
    char name[50];
    float cost;
};

void display(struct Product p[], int n) {
    printf("
Products with cost between 100-1000:
");
    printf("Pno	Name		Cost
");
    for (int i = 0; i < n; i++)
        if (p[i].cost >= 100 && p[i].cost <= 1000)
            printf("%d	%s	%.2f
", p[i].pno, p[i].name, p[i].cost);
}

int main() {
    struct Product *p;
    int n;
    printf("Enter number of products: ");
    scanf("%d", &n);
    p = (struct Product *)malloc(n * sizeof(struct Product));
    printf("Enter product details (pno name cost):
");
    for (int i = 0; i < n; i++) {
        scanf("%d", &p[i].pno);
        getchar();
        fgets(p[i].name, 50, stdin);
        p[i].name[strcspn(p[i].name, "
")] = 0;
        scanf("%f", &p[i].cost);
    }
    display(p, n);
    free(p);
    return 0;
}