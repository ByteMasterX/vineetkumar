# DS-Lab: Data Structures Laboratory

Complete collection of C programs for Data Structures Laboratory course.

## 📁 Directory Structure

```
DS-Lab/
├── README.md
├── Experiment-1-Functions-and-Arrays/
│   ├── max_min.c
│   ├── insertion.c
│   ├── deletion.c
├── Experiment-2-Matrix-and-Sparse-Matrix/
│   ├── matrix_multiplication.c
│   ├── matrix_transpose.c
│   ├── sparse_matrix.c
├── Experiment-3-Pointer-Structure-DMA/
│   ├── largest_dma.c
│   ├── student_structure.c
│   ├── product_structure.c
├── Experiment-4-Stack-and-Queue/
│   ├── stack_operations.c
│   ├── linear_queue.c
│   ├── circular_queue.c
├── Experiment-5-Searching-and-Sorting/
│   ├── binary_search.c
│   ├── selection_sort.c
│   ├── bubble_sort_string.c
├── Experiment-6-Sorting-and-Merging/
│   ├── merge_arrays.c
│   ├── insertion_sort.c
│   ├── quick_sort.c
├── Experiment-7-Single-Linked-List/
│   ├── sll_beginning.c
│   ├── sll_end.c
│   ├── sll_position.c
├── Experiment-8-Linked-Stack-and-Queue/
│   ├── linked_stack.c
│   ├── linked_queue.c
├── Experiment-9-Double-Linked-List/
│   ├── dll_beginning.c
│   ├── dll_end.c
├── Experiment-10-Advanced-Linked-List/
│   ├── cricket_players.c
│   ├── bank_accounts.c
```

## 🗂️ Experiments Overview

| Experiment | Description | Programs |
|------------|-------------|----------|
| 1 | Functions and Arrays - Basic UDF operations | 3 |
| 2 | Matrix operations and sparse matrix handling | 3 |
| 3 | Pointers, Structures, and Dynamic Memory Allocation | 3 |
| 4 | Stack and Queue implementations using arrays | 3 |
| 5 | Searching and Sorting algorithms | 3 |
| 6 | Advanced sorting and merging techniques | 3 |
| 7 | Single Linked List operations | 3 |
| 8 | Linked Stack and Linked Queue implementations | 2 |
| 9 | Double Linked List operations | 2 |
| 10 | Advanced Linked List applications | 2 |

## 🚀 How to Compile and Run

### Using GCC:
```bash
cd "D:/DS-Lab/Experiment-1-Functions-and-Arrays"
gcc max_min.c -o max_min.exe
max_min.exe
```

### Using Code::Blocks:
1. Open Code::Blocks
2. Create new project or open individual .c files
3. Build and Run

## 📝 Program Details

### Experiment 1: Functions and Arrays
- **max_min.c**: Find maximum and minimum in an array using UDF
- **insertion.c**: Insert element at specific position in array
- **deletion.c**: Delete element from specific position in array

### Experiment 2: Matrix and Sparse Matrix
- **matrix_multiplication.c**: Multiply two matrices using UDF
- **matrix_transpose.c**: Find transpose of square matrix
- **sparse_matrix.c**: Check sparse matrix and store non-zero positions

### Experiment 3: Pointer, Structure and DMA
- **largest_dma.c**: Dynamic memory allocation to find largest element
- **student_structure.c**: Structure array for student records (age >= 20)
- **product_structure.c**: DMA for product records (cost 100-1000)

### Experiment 4: Stack and Queue
- **stack_operations.c**: Stack implementation using array (push, pop, display)
- **linear_queue.c**: Linear queue using array (insert, delete, traverse)
- **circular_queue.c**: Circular queue using array (insert, delete, traverse)

### Experiment 5: Searching and Sorting
- **binary_search.c**: Binary search algorithm implementation
- **selection_sort.c**: Selection sort algorithm
- **bubble_sort_string.c**: Bubble sort for string characters

### Experiment 6: Sorting and Merging
- **merge_arrays.c**: Merge two sorted arrays into one
- **insertion_sort.c**: Insertion sort algorithm
- **quick_sort.c**: Quick sort algorithm

### Experiment 7: Single Linked List
- **sll_beginning.c**: Insert/delete at beginning of SLL
- **sll_end.c**: Insert/delete at end of SLL
- **sll_position.c**: Insert at position and search in SLL

### Experiment 8: Linked Stack and Queue
- **linked_stack.c**: Stack implementation using linked list
- **linked_queue.c**: Queue implementation using linked list

### Experiment 9: Double Linked List
- **dll_beginning.c**: Insert/delete at beginning of DLL
- **dll_end.c**: Insert/delete at end of DLL

### Experiment 10: Advanced Linked List
- **cricket_players.c**: SLL for cricket players (batting avg >= 50)
- **bank_accounts.c**: DLL for bank accounts with total balance calculation

## 👨‍💻 Author: 25ECE017
Generated from DS Lab PDFs
Date: 2026-03-25
